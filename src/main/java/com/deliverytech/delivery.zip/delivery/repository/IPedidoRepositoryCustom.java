package com.deliverytech.delivery.repository;

import java.math.BigDecimal;
import java.util.List;

import com.deliverytech.delivery.model.PedidoModel;

public interface IPedidoRepositoryCustom {

}
