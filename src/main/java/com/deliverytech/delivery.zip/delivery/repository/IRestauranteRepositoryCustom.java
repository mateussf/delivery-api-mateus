package com.deliverytech.delivery.repository;

public interface IRestauranteRepositoryCustom {

}
