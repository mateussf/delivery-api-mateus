package com.deliverytech.delivery.service;

public interface IRestauranteService {

}
